import { Component } from '@angular/core';
import { keraladata } from '../../models/keraladata.interface';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {
  data: keraladata[] = [];
 
  constructor() {
    this.fetchData();
  }
  async fetchData() {
    const url = 'https://fluffy-reinvented-night.glitch.me/keraladata';
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Error: ${response.statusText}`);
      }
      const data = await response.json();
      console.log(data)
      this.data = data;
     } catch (error) {
      console.error('Error fetching data:', error);
    }
  }
}
