export interface keraladata{
    name:"string"
    description:"string"
    images:"string"
}