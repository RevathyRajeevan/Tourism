import { placeToVisit } from "./placeToVisit.interface"
export interface district{
    name:"string"
    description:"string"
    detail_description:"string"
    places_to_visit:[]
    images:"string"
    id:number
}